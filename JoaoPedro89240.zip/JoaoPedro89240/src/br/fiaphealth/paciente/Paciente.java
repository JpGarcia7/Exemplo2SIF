package br.fiaphealth.paciente;

public class Paciente {
	
	private String cpf;
	private String nome;
	private String fone;
	
	public Paciente(String cpf, String nome, String fone) {
		this.cpf = cpf;
		this.nome = nome;
		this.fone = fone;
	}
	
	public String getDados() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Cpf: " + cpf + "\n";
		aux += "Fone: " + fone + "\n";
		return aux;
	}
	

}
