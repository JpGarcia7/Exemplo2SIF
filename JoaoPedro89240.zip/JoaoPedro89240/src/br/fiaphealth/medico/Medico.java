package br.fiaphealth.medico;

public class Medico {
	
	private int crm;
	private String nome;
	private String especialidade;
	int total;
	
	public Medico (int crm, String nome, String especialidade) {
		this.crm = crm;
		this.nome = nome;
		this.especialidade = especialidade;
	}

	public String getDados() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Crm: " + crm + "\n";
		aux += "Especialidade: " + especialidade + "\n";
		return aux;
	}
	
	

}
