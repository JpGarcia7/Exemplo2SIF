package br.fiaphealth.main;

import java.util.Scanner;
import br.fiaphealth.paciente.Paciente;
import br.fiaphealth.medico.Medico;
import br.fiaphealth.consulta.Consulta;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Consulta[] consulta = new Consulta[4];
		
		consulta[0] = new Consulta();
		consulta[1] = new Consulta();
		consulta[2] = new Consulta();
		consulta[3] = new Consulta();
		
		for(Consulta c : consulta) {
			System.out.println(c.getDados());
		}

	}

}


