package br.fiaphealth.consulta;

import br.fiaphealth.paciente.Paciente;
import br.fiaphealth.medico.*;

public class Consulta {
	
	private String data;
	private Paciente paciente;
	private Medico medico;
	
	public Consulta(String data, Paciente paciente, Medico medico) {
		this.data = data;
		this.paciente = paciente;
		this.medico = medico;
	}

	public Consulta(Paciente paciente, Medico medico) {
		super();
		this.data = "25/04/2022";
		this.paciente = paciente;
		this.medico = medico;
	}
	
	public String getDados() {
		String aux = "";
		aux += "Data: " + data + "\n";
		aux += "Paciente: " + paciente + "\n";
		aux += "Medico: " + medico + "\n";
		return aux;
	
	}
	
	

}
