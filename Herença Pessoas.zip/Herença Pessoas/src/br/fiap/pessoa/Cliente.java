package br.fiap.pessoa;

public class Cliente extends Pessoa {
	
	private double valorDivida;

	public Cliente(String nome, String cpf, double valorDivida) {
		super(nome, cpf);
		this.valorDivida = valorDivida;
	}

	
	

}
