package br.fiap.empregado;

import br.fiap.pessoa.Pessoa;

public class Vendedor extends Pessoa {
	
	private double totalVendas;
	private double comissao;
	
	
	public Vendedor(String nome, String cpf, double totalVendas, double comissao) {
		super(nome, cpf);
		this.totalVendas = totalVendas;
		this.comissao = comissao;
	}
	
	

}
