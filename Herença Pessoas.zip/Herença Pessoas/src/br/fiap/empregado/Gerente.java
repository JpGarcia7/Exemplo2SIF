package br.fiap.empregado;

import br.fiap.pessoa.Pessoa;

public class Gerente extends Pessoa {
	

	private double salario;
	private double bonus;
	
	
	public Gerente(String nome, String cpf, double salario, double bonus) {
		super(nome, cpf);
		this.salario = salario;
		this.bonus = bonus;
	}
	
	

}
