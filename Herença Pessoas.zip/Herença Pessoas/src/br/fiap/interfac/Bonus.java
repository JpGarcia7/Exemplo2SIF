package br.fiap.interfac;

public interface Bonus {

	public abstract double calcularBonus();
	
}
