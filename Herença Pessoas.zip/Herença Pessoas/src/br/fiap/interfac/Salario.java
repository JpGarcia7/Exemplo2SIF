package br.fiap.interfac;

public interface Salario {

	public abstract double calcularSalario();
	
}
