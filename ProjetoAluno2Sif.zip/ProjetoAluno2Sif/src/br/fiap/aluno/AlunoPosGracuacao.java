package br.fiap.aluno;

public class AlunoPosGracuacao extends Aluno {

	//metodo para calcular e retornar a m�dia
		public double calcularMedia() {
			
		}

	
}
