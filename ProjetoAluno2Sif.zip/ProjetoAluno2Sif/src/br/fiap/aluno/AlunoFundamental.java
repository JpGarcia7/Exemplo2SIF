package br.fiap.aluno;

public class AlunoFundamental extends Aluno {
	
	//atributo especifico da classe
	private int serie;
	
	//metodo para calcular e retornar a m�dia
		public double calcularMedia() {
			return (prova1 + prova2) /2;
		}


}
