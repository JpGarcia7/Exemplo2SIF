package br.fiap.aluno;

public abstract class Aluno {

	// atributos que ser�o compartilhados
	protected long rm;
	protected String nome;
	protected double prova1;
	protected double prova2;
	
	
	
}
