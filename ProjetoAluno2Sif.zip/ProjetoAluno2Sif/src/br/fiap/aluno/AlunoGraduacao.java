package br.fiap.aluno;

public class AlunoGraduacao extends Aluno {
	
	//atributos especificos
	private String curso;
	private double trabalho;
	
	//metodo para calcular e retornar a m�dia
	public double calcularMedia() {
		
	}

}
