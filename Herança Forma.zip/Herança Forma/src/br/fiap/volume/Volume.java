package br.fiap.volume;

public interface Volume {
	
	public abstract double calcularVolume();

}
