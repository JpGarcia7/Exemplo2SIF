package principal;

import paciente.Paciente;

public class Principal {

public static void main(String[] args) {
		
		Paciente p = new Paciente();
		p.setNome("Garcia");
		System.out.println(p.getNome());
		}

}
