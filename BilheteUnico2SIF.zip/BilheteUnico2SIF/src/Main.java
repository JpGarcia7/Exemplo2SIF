import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
	
		Util util = new Util();
		util.menuPricipal();
		
		
		
	}
}

