
public class Usuario {
	
	//Atributos
	String nome;
	String cpf;
	String tipo; // Estudante/Professor/Normal
	
	//codifica��o do construtor
	public Usuario(String nome, String cpf, String tipo) {
		this.nome = nome;
		this.cpf = cpf;
		this.tipo = tipo;
		
	}
	
	
	

}
