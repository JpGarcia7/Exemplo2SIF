import static javax.swing.JOptionPane.*;
import static java.lang.Integer.*;
import static java.lang.Double.*;

public class Util {

	// array para armazenar objetos do tipo Bilhete
	private BilheteUnico[] bd = new BilheteUnico[5];

	// variavel para controlar as posicoes do array
	private int index = 0;

	public void menuPricipal() {
		String aux = "Escolha uma opera��o:\n1. Administrador\n2. Usu�rio\n3. Finalizar";
		int opcao;

		do {
			opcao = parseInt(showInputDialog(aux));
			if (opcao < 1 || opcao > 3) {
				showMessageDialog(null, "Opc�o Inv�lida");
			} else {
				if (opcao == 1) {
					menuAdminitrador();
				} else if (opcao == 2) {
					menuUsuario();
				}
			}
		} while (opcao != 3);

	}

	public void menuAdminitrador() {
		String aux = "Escolha uma opera��o:\n";
		aux += "1. Cadastrar Bilhete\n";
		aux += "2. Consultar Bilhete\n";
		aux += "3. Sair";
		int opcao;

		do {
			opcao = parseInt(showInputDialog(aux));
			if (opcao < 1 || opcao > 3) {
				showMessageDialog(null, "Opc�o Inv�lida");
			} else if (opcao == 1) {
				cadastrarBilhete();
			} else if (opcao == 2) {
				consultarBilhete();
			}
		} while (opcao != 3);

	}

	public void menuUsuario() {

		String aux = "Escolha uma opera��o:\n";
		aux += "1. Consultar Saldo\n";
		aux += "2. Carregar Bilhete\n";
		aux += "3. Passar na Catraca\n";
		aux += "4. Sair";
		int opcao;

		do {
			opcao = parseInt(showInputDialog(aux));
			if (opcao < 1 || opcao > 4) {
				showMessageDialog(null, "Op��o Inv�lida");
			} else if (opcao ==1){
				consultarSaldo();
			} else if (opcao == 2) {
				carregarBilhete();
			}else if (opcao ==3) {
				passarNaCatraca();
			}
		} while (opcao != 4);

	}

	public void cadastrarBilhete() {
		if (index < bd.length) {
			String nome = showInputDialog("Nome: ");
			String cpf = showInputDialog("CPF: ");
			String tipo = showInputDialog("Tipo (Aluno/Professor/Normal): ");
			bd[index] = new BilheteUnico(nome, cpf, tipo);
			index++;
		} else {
			showMessageDialog(null, "Proure um posto autorizado");
		}
	}

	// metodo auxiliar para pequisar um bilhete pelo cpf do usuario
	// metodo retorna a posi��o valida do array ou -1 se n�o encontrar o objeto

	public int pesquisar(String cpf) {
		int aux = -1;
		for (int i = 0; i < index; i++) {
			if (bd[i].usuario.cpf.equals(cpf)) {
				aux = i;
				break;
			}

		}
		return aux;
	}

	// metodo para consultar e exibir os dados do bilhete (menu Administrador)
	public void consultarBilhete() {
		int posicao;
		String aux, cpf;

		cpf = showInputDialog("Informe Cpf a ser pesquisado");
		posicao = pesquisar(cpf);
		if (posicao == -1) {
			showMessageDialog(null, cpf + "n�o encotrado");
		} else {
			aux = "numero do bihete: " + bd[posicao].numero + "\n ";
			aux += "Nome do usuario:" + bd[posicao].usuario.nome + "\n";
			aux += "Cpf do usuario: R$ " + "\n";
			aux += "Saldo do usuario: R$ " + String.format("%.2f", bd[posicao].saldo) + "\n";
			aux += "Tipo da tarifa: " + bd[posicao].usuario.tipo;
			showMessageDialog(null, aux);

		}
	}

	//metodo para consultar o saldo de um bilhete do usuario
	public void consultarSaldo() {
		String cpf;
		int posicao;
		
		cpf = showInputDialog("CPF");
		posicao = pesquisar(cpf);
		if(posicao == -1) {
			showMessageDialog(null, cpf + "N�o Encontrado");
		}else {
			showMessageDialog(null, "Saldo R$ "+String.format("%.2f", bd[posicao].consultarSaldo()));
		}
	}
	
	//metodo para carregar o bilhete com um valor informado pelo o usuario
	public void carregarBilhete() {
		String cpf;
		int posicao;
		
		cpf = showInputDialog("CPF");
		posicao = pesquisar (cpf);
		
		if (posicao == -1) {
			showMessageDialog(null, cpf + "N�o Encontrado");
		}else {
		double valor = parseDouble(showInputDialog("Informe o valor da recarga"));
		bd[posicao].carregar(valor);
		}
	}
	
	//metodo para passar na catraca
	public void passarNaCatraca() {
		
		String cpf = showInputDialog("CPF");
		int posicao = pesquisar(cpf);
		if (posicao == -1) {
			showMessageDialog(null, cpf + "Erro");
		}else {
		 bd[posicao].passarNaCatraca();
		}
		
		
	}
	
	
}
