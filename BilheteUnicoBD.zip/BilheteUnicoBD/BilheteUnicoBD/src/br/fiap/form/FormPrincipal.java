package br.fiap.form;
import static javax.swing.JOptionPane.showInputDialog;

import br.fiap.dao.BilheteUnicoDAO;
import br.fiap.modelo.BilheteUnico;

public class FormPrincipal {

	
	public void menuPrincipal() {
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		BilheteUnico bilhete;
		String opcao;
		
		do {
			opcao = showInputDialog("Digite sua senha ou CPF ou Sair");
			if(opcao.equalsIgnoreCase("admin")) {
				new FormAdmin().menuAdmin();
			} else if (!opcao.equalsIgnoreCase("sair")) {
				bilhete = dao.pesquisarCPF(opcao);
				if(bilhete !=null) {
					new FormUsuario().menuUsuario(opcao);
				}
			}
		} while(!opcao.equalsIgnoreCase("sair"));		
	}
	
}
