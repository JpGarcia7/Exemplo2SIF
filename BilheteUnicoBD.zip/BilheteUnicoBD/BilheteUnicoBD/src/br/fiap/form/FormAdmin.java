package br.fiap.form;
import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showOptionDialog;

import java.util.List;
import java.util.Random;

import br.fiap.dao.BilheteUnicoDAO;
import br.fiap.modelo.BilheteUnico;
import br.fiap.modelo.Usuario;

public class FormAdmin {

	public void menuAdmin() {
		int opcao = 0;
		
		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuAdmin()));
				switch(opcao) {
					case 1:
						emitirBilhete();
						break;
					case 2:
						listarBilhete();
						break;
					case 3:
						pesquisarBilhete();
						break;
				}
			}
			catch(NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número\n" + e);
			}
			
		} while(opcao != 4);
		
	}

	private void listarBilhete() {
		
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		List<BilheteUnico> lista = dao.listar();
		String aux = "";
		
		for (BilheteUnico bilhete : lista) {
			aux += "Numero do Bilhete: " + bilhete.getNumero() + "\n";
			aux += "Numero do CPF: " + bilhete.getCpfUsuario() + "\n";
			aux += "Saldo R$: " + String.format("%.2f", bilhete.getSaldo()) + "\n \n";
		}
		
		showMessageDialog(null, aux);
	}

	private void pesquisarBilhete() {
		
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		BilheteUnico bilhete;
		String cpf, aux;
		
		cpf = showInputDialog("CPF do Usuario");
		bilhete = dao.pesquisarCPF(cpf);
		if(bilhete == null) {
			showMessageDialog(null, "CPF não cadastrado");
		}else {
			aux = "Numero do bilhete: " + bilhete.getNumero() + "\n";
			aux += "CPF do Usuário: " + cpf + "\n";
			aux += "Saldo do bilhete R$: " + String.format("%.2f", bilhete.getSaldo());
			showMessageDialog(null, aux);
		}
		
	}

	private void emitirBilhete() {
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		Random gerador = new Random();
		String cpf;
		int numero;
		String nome;
		int tipo;
		String opcao[] = {"Estudante", "Professor", "Normal"};
		
		cpf = showInputDialog("CPF do usuário");
		if(dao.pesquisarCPF(cpf) == null) {
			// gerar um número que não pode ser repetido
			do {
				numero = gerador.nextInt(1000, Integer.MAX_VALUE);				
			} while(dao.pesquisarNumero(numero));
			
			nome = showInputDialog("Nome do usuário");
			tipo = showOptionDialog(null, "Tipo de tarifa", "Tipo de tarifa", 0, 0, null, opcao, opcao[0]);
						
			Usuario usuario = new Usuario(nome, cpf, opcao[tipo]);
			BilheteUnico bilhete = new BilheteUnico(numero, cpf, 0); 
			dao.emitir(usuario, bilhete);
					
		} else {
			showMessageDialog(null, "Usuário com bilhete cadastrado");
		}
		
	}

	private String gerarMenuAdmin() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Emitir Bilhete\n";
		menu += "2. Imprimir Bilhete\n";
		menu += "3. Consultar Bilhete\n";
		menu += "4. Sair";
		return menu;
				
	}
	
}
