package br.fiap.main;

import br.fiap.form.FormPrincipal;

public class Main {
	public static void main(String[] args) {
		
		new FormPrincipal().menuPrincipal();
		
	}
}
