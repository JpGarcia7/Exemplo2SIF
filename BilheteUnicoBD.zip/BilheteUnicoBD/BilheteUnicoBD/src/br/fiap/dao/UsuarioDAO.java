package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Usuario;

public class UsuarioDAO {
	
	// atributos para manipulação do banco de dados
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	// construtor para conectar na base de dados
	public UsuarioDAO() {
		connection = new Conexao().conectar();
	}
		
	// método para inserir o usuário na tabela java_usuario
	public void inserir(Usuario usuario) {
		sql = "insert into java_usuario(nome, cpf, tipo) values (?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, usuario.getNome());
			ps.setString(2, usuario.getCpf());
			ps.setString(3, usuario.getTipo());
			ps.execute();
		}
		catch(SQLException e) {
			System.out.println("Erro ao inserir dados do usuário\n" + e);
		}
	}
	
	
}
