package br.fiap.modelo;

public class BilheteUnico {
	private int numero;
	private String cpfUsuario;
	private double saldo;
	public static final double valorPassagem = 4.4;
	
	public BilheteUnico(String cpfUsuario) {
		super();
		this.cpfUsuario = cpfUsuario;
	}
	
	public BilheteUnico(int numero, String cpfUsuario, double saldo) {
		super();
		this.numero = numero;
		this.cpfUsuario = cpfUsuario;
		this.saldo = saldo;
	}



	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getCpfUsuario() {
		return cpfUsuario;
	}

	public void setCpfUsuario(String cpfUsuario) {
		this.cpfUsuario = cpfUsuario;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public static double getValorpassagem() {
		return valorPassagem;
	}	
}
